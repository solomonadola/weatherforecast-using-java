<?php
session_start();
if (!isset($_SESSION['manid'])) {
    header("location: ../Admin/manglogin.php");
    exit();
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./admin.css">
    <style>

    </style>
    <title>Manger Dashboard</title>
</head>

<body>
    <div class="side-menu">
        <div class="brand-name">

            <h1 style="color: yellow">Dembela Site</h1>
        </div>

        <ul>
            <li>Dashboard</li>

            <li><a href="../server/mlogout.php" style="color: red;">logout</a></li>
        </ul>
        <div class="mesage">
            <div class="form">
                <form action="../server/sendmessage.php" class="mform" method="POST">

                    <textarea id="textarea" name="textarea" rows="10" cols="100" placeholder="Message"></textarea>
                    <input type="submit" name="submit" id="button" value="Send Message">
                </form>

            </div>
        </div>
    </div>
    <div class="container">
        <div class="header">
            <div class="nav">
                <div class="search">
                    <input type="text" name="" placeholder="Search....">
                    <button type="submit"> Search</button>
                </div>
               
            </div>
        </div>
        <div class="content">
            <div class="cards">
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?>
                        </h1>
                        <h3>Clients</h3>
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable where status='accepted'")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?>
                        </h1>
                        <h3>Accepted Clients</h3>
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable where status='pending'")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?></h1>
                        <h3>Pending Clients</h3>
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable where status='rejected'")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?></h1>
                        <h3>Rejected Clients</h3>
                    </div>
                </div>
            </div>
            <div class="content-2">
                <div class="Recent-Created">
                    <div class="title">
                        <h2>clients</h2>
                    </div>
                    <table>

                        <?php
                        if (isset($_SESSION['message'])) : ?>
                            <?php
                            if ($_SESSION['type'] === 'accepted') :
                            ?>

                                <div style="background-color: green; color:white; padding:1rem; text-align:center;">
                                <?php else : ?>
                                    <div style="background-color: red; padding:1rem; text-align:center;">

                                    <?php endif ?>

                                    <?php
                                    echo $_SESSION['message'];
                                    unset($_SESSION['message']);
                                    ?>
                                    </div>
                                <?php endif
                                ?>
                                <tr>
                                    <th>Name</th>
                                    <th>PhoneNo</th>
                                    <th>zone</th>
                                    <th>registration date</th>
                                    <th>Profile</th>
                                    <th>status</th>
                                </tr>
                                <?php
                                include_once '../server/database.php';
                                $result = $con->query(("select * from regtable")) or die($con->error);
                                ?>
                                <?php
                                while ($row = $result->fetch_assoc()) :
                                ?>
                                    <tr>
                                        <td><?php echo $row['name'] ?></td>
                                        <td><?php echo $row['phone'] ?></td>
                                        <td><?php echo $row['zone'] ?></td>
                                        <td><?php echo $row['regdate'] ?></td>
                                        <td><a href="<?php echo $row['floc']; ?>" class="btn" target="_blank">view</a></td>
                                        <td><?php echo $row['status']; ?></td>

                                    </tr>
                                <?php
                                endwhile; ?>


                    </table>
                    
                    
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php
include_once '../server/session.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./admin.css">

    <title>Admin Dashboard</title>
</head>

<body>
    <div class="side-menu">
        <div class="brand-name">

            <h1 style="color: yellow">Dembela Site</h1>
        </div>

        <ul>
            <li>Dashboard</li>

            <li><a href="../server/logout.php" style="color: red;">logout</a></li>
        </ul>
        <div class="mesage">
            <div class="form">
                <form action="./messageprocess.php"  method="POST" class="mform">
                    <div style="width: 19vw; height: 400px; background-color: white; overflow: scroll;">

                        <?php
                        include_once '../server/database.php';
                        $result = $con->query(("select * from message where mr='unread'")) or die($con->error);

                        $count = 1;

                        while ($row = $result->fetch_assoc()) {
                            echo "<p style='color:blue; text-alight:center;''>message " . $count . "</p> ";
                            echo ($row['messagebody']."<br><br>");
                            $count++;
                        }

                        ?>
                    </div>
                    <div class="btnss">
                    <input type="submit" name="submit" id="button" class="rn" value="mark all as read" style="padding: 10px;margin: 15px;font-size: 100%;">

                    </div>

                </form>

            </div>
        </div>
    </div>
    <div class="container">
        <div class="header">
            <div class="nav">
                <div class="search">
                    <input type="text" name="" placeholder="Search....">
                    <button type="submit"> Search</button>
                </div>
                
            </div>
        </div>
        <div class="content">
            <div class="cards">
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?>
                        </h1>
                        <h3>Clients</h3>
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable where status='accepted'")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?>
                        </h1>
                        <h3>Accepted Clients</h3>
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable where status='pending'")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?></h1>
                        <h3>Pending Clients</h3>
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1 style="text-align: center;">
                            <?php
                            include_once '../server/database.php';
                            $count = 0;
                            $result = $con->query(("select * from regtable where status='rejected'")) or die($con->error);
                            while ($row = $result->fetch_assoc()) {
                                $count++;
                            }
                            echo $count;
                            ?></h1>
                        <h3>Rejected Clients</h3>
                    </div>
                </div>
            </div>
            <div class="content-2">
                <div class="Recent-Created">
                    <div class="title">
                        <h2>clients</h2>
                    </div>
                    <table>
                        <col style="width:20%">
                        <col style="width:15%">
                        <col style="width:10%">
                        <col style="width:12%">
                        <col style="width:5%">
                        <col style="width:10%">
                        <col style="width:5%">
                        <col style="width:5%">
                        <col style="width:5%">
                        <?php
                        if (isset($_SESSION['message'])) : ?>
                            <?php
                            if ($_SESSION['type'] === 'accepted') :
                            ?>

                                <div style="background-color: green; color:white; padding:1rem; text-align:center;">
                                <?php else : ?>
                                    <div style="background-color: red; padding:1rem; text-align:center;">

                                    <?php endif ?>

                                    <?php
                                    echo $_SESSION['message'];
                                    unset($_SESSION['message']);
                                    ?>
                                    </div>
                                <?php endif
                                ?>
                                <tr>
                                    <th>Name</th>
                                    <th>PhoneNo</th>
                                    <th>zone</th>
                                    <th>registration date</th>
                                    <th>Profile</th>
                                    <th>status</th>
                                    <th colspan="3" style="text-align: center;">Action</th>
                                </tr>
                                <?php
                                include_once '../server/database.php';
                                $result = $con->query(("select * from regtable")) or die($con->error);
                                ?>
                                <?php
                                while ($row = $result->fetch_assoc()) :
                                ?>
                                    <tr>
                                        <td><?php echo $row['name'] ?></td>
                                        <td><?php echo $row['phone'] ?></td>
                                        <td><?php echo $row['zone'] ?></td>
                                        <td><?php echo $row['regdate'] ?></td>
                                        <td><a href="<?php echo $row['floc']; ?>" class="btn" target="_blank">view</a></td>
                                        <td><?php echo $row['status']; ?></td>
                                        <?php
                                        if ($row['status'] === 'pending' || $row['status'] === 'rejected') : ?>

                                            <td style="text-align: center;"><a href="../server/process.php?accept=<?php echo $row['userid']; ?>" class="btn">accept</a></td>
                                        <?php
                                        else :
                                        ?>
                                            <td style="text-align: center;"><a href="#" class="btn">accept</a></td>

                                        <?php

                                        endif ?>
                                        <?php
                                        if ($row['status'] === 'rejected') : ?>

                                            <td style="text-align: center; "><a href="#" class="btn">reject</a></td>
                                        <?php
                                        else : ?>
                                            <td style="text-align: center; "><a href="../server/process.php?reject=<?php echo $row['userid']; ?>" class="btn">reject</a></td>

                                        <?php
                                        endif ?>

                                        <td style="text-align: center;"><a href="../server/process.php?delete=<?php echo $row['userid']; ?>" class="btn">delete</a></td>


                                    </tr>
                                <?php
                                endwhile; ?>


                    </table>

                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php
session_start();

if (isset($_POST["submit"])) {

    require_once '../server/database.php';

    $sql = "update  message set mr='read' where mr='unread'";
    $con->query(($sql)) or die($con->error);
    mysqli_close($con);
    header("location: admindashboard.php");
        exit();
    
} else {
    header("location:./login.php");


}

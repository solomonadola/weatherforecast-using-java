<?php
session_start();
if (isset($_SESSION['userid'])) {
    header("location: ./server/ulogout.php");
}
?>
<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>
    <link rel="stylesheet" href="./css/style.css" />
    <link rel="stylesheet" href="./fonts/stylesheet.css" />
    <link rel="stylesheet" href="./css/all.css" />
</head>

<body>
    <header>

        <div class="container flex">
            <a href="./index.html" class="nav-brand"><i class="fas fa-home"></i> Dembela Site CMS</a>
            <ul class="flex">
                <li>
                    <a href="./index.html"><i class="fas fa-home"></i> Home</a>
                </li>
                <li>
                    <a href="./gallery.html"><i class="fas fa-image"></i> Gallery</a>
                </li>
                <li>
                    <a href="./contact.html"><i class="fas fa-phone"></i> Contact</a>
                </li>
                <li>
                    <a class="active" href="./login.php"><i class="fas fa-sign-in-alt"></i> Login/Sign up</a>
                </li>
                <li>
                    <a href="./Admin/login.php"><i class="fas fa-sign-in-alt"></i> Admin Login</a>
                </li>
            </ul>
            <div class="menu">
                <i class="fas fa-bars"></i>
              </div>
        </div>
    </header>

    <div class="form_sec my-4">
        <div class="container">
            <div class="form">
                <h2><i class="fas fa-sign-in-alt"></i> Login</h2>
                <form action="server/loginprocess.php" method="POST">
                    <div class="form-group">
                        <label for="userid">Userid</label>
                        <input id="userid" name="userid" type="text" placeholder="Enter id " />
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" placeholder="enter password">
                    </div>
                    <button type="submit" name="submit"><i class="fas fa-sign-in-alt"></i> Login</button>
                </form>
                <p>
                    <a href="#">Forget password?</a>
                    <a href="./register.php">Create Account?</a>
                </p>
            </div>
        </div>
    </div>
    <footer class="py-1">
        <div class="container">
            <span>CopyRight &copy; Dembela site All Rights Reserved</span>
        </div>
    </footer>
    <script src="./script.js"></script>
</body>

</html>
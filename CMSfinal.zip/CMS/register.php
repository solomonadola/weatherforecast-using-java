
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register</title>
    <link rel="stylesheet" href="./css/style.css" />
    <link rel="stylesheet" href="./fonts/stylesheet.css" />
    <link rel="stylesheet" href="./css/all.css" />
</head>

<body >
    <header>
        <div class="container flex">
            <a href="./index.html" class="nav-brand"><i class="fas fa-home"></i> Dembela Site CMS</a>
            <ul class="flex">
                <li>
                    <a href="./index.html"><i class="fas fa-home"></i> Home</a>
                </li>
                <li>
                    <a href="./gallery.html"><i class="fas fa-image"></i> Gallery</a>
                </li>
                <li>
                    <a href="./contact.html"><i class="fas fa-phone"></i> Contact</a>
                </li>
                <li>
                    <a class="active" href="./login.php"><i class="fas fa-sign-in-alt"></i> Login/Sign up</a>
                </li>
                <li>
                    <a href="./Admin/login.php"><i class="fas fa-sign-in-alt"></i> Admin Login</a>
                </li>
            </ul>
            <div class="menu">
                <i class="fas fa-bars"></i>
              </div>

        </div>
    </header>
   
    <div class="form_sec my-4">
        <div class="container">
            <div class="form">
            <?php
                if (isset($_GET["error"])) {
                    if ($_GET["error"] == "emptyinput") {
                        echo '<p style="background-color: red; color: white";>fill in all fields!!</p>';
                    }
                }
                ?><br>
                <h2><i class="fas fa-user-plus"></i> Register</h2>
                <form action="server/regprocess.php" method="POST" enctype="multipart/form-data" >

                    <div class="form-group">
                        <label for="name">First name</label>
                        <input id="fname" name="fname" type="text" placeholder="First name" />
                    </div>
                    <div class="form-group">
                        <label for="name">Last name</label>
                        <input id="lname" name="lname" type="text" placeholder="Last name" />
                    </div>
                    <div class="form-group">
                        <label for="userid">User Id</label>
                        <input type="text" name="userid" placeholder="Enter id" />
                    </div>
                    <div class="form-group">
                        <label for="nPassword">New Password</label>
                        <input id="nPassword" name="npassword" type="password" placeholder="Password" />
                    </div>
                    <div class="form-group">
                        <label for="cpassword">Confirm Password</label>
                        <input id="cpassword" name="cpassword" type="password" placeholder="Confirm Password" />
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone number</label>
                        <input id="phone" name="phone" type="tel" placeholder="Phone" />
                    </div>
                    <div class="form-group">
                        <label for="zone">Zone</label>
                        <input id="zone" name="zone" type="text" placeholder="Zone" />
                    </div>
                    <div class="form-group">
                        <label for="disablity">Disablity Status</label>
                        <select name="disablity" id="disablity">
                            <option value="none">None</option>
                            <option value="disable">Disable</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="file">Attach File</label>
                        <input id="file" name="file" type="file" placeholder="Choose file" />
                    </div>
                    <button name="submit" type="submit"><i class="fas fa-user-plus"></i> Register</button>
                </form>
                <br>
               
                <p>
                    Already registered?
                    <a href="./login.php">Login</a>
                </p>
            </div>
        </div>
    </div>
    <footer class="py-1">
        <div class="container">
            <span>CopyRight &copy; Dembela site All Rights Reserved</span>
        </div>
    </footer>
    <script src="./script.js"></script>
</body>

</html>
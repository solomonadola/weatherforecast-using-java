<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("location: ../login.php");
    exit();
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/admin.css">
    <style>

    </style>
    <title>User Dashboard</title>
</head>

<body>
    <div class="side-menu">
        <div class="brand-name">

            <h1 style="color: yellow">Dembela Site</h1>
        </div>

        <ul>
            <li>Dashboard</li>

            <li><a href="../server/ulogout.php" style="color: red;">logout</a></li>
        </ul>
        
    </div>
    
    <div class="container">


        <div class="content-2">
            <div class="Recent-Created">
                <div class="title">
                </div>
                <table>


                    <tr>
                        <th>Name</th>
                        <th>registration date</th>
                        <th>status</th>
                    </tr>
                    <?php
                    include_once '../server/database.php';
                    $uid = $_SESSION['userid'];
                    $result = $con->query(("select * from regtable where userid='$uid' ")) or die($con->error);
                    ?>
                    <?php
                    while ($row = $result->fetch_assoc()) :
                    ?>
                        <tr>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['regdate'] ?></td>
                            <td><?php echo $row['status']; ?></td>

                        </tr>
                    <?php
                    endwhile; ?>


                </table>
                <div class="mesagearea">
                    <div class="title">
                        <h1>notifications</h1>
                    </div>
                    <div class="contain">
                        
                    </div>
                </div>


            </div>
        </div>
    </div>
    </div>
</body>

</html>
let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");

function toggleMenu() {
  toggle.classList.toggle("active");
  navigation.classList.toggle("active");
}
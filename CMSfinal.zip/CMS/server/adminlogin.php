<?php
session_start();
if (isset($_POST['submit'])) {
    $id = $_POST['adminid'];
    $pwd = $_POST['password'];
    include_once '../server/functions.php';
    include_once 'database.php';
    
    if (emptyInputLogin($id, $pwd)) {
        header("location:../Admin/login.php?error=emptyintput");
        exit();
    }
    else{
        loginAdmin($con,$id,$pwd);
    }
} else {
    header("location:../Admin/login.php");
    exit();
}

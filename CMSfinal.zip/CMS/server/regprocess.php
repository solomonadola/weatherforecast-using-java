<?php
if (isset($_POST['submit'])) {
    $name = $_POST['fname'] . " " . $_POST['lname'];
    $id = $_POST['userid'];
    $npassword = $_POST['npassword'];
    $cpassword = $_POST['cpassword'];
    $phone = $_POST['phone'];
    $zone = $_POST['zone'];
    $disablity = $_POST['disablity'];
    $file = $_FILES['file']['name'];
    $regdate = date("Y-m-d");
    require_once 'database.php';
    require_once 'functions.php';
    if (emptyInputSignup($name, $id, $npassword, $cpassword, $phone, $zone, $disablity, $file)) {
        header("location:../register.php?error=emptyinput");
        exit();
    }
    if (checkpassword($npassword, $cpassword)) {
        header("location:../register.php?error=passworddonotmatch");
        exit();
    }
    if (uidexist($con, $id,$cpassword)) {
        header("location:../register.php?error=usernamealreadyexist");
        exit();
    }
    if (signup($con, $name, $id, $npassword, $phone, $zone, $disablity, $file, $regdate)) {
        header("location:../login.php");
        exit();
    }
} else {
    header("location:../index.com");
}

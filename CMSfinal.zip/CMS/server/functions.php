<?php
function emptyInputSignup($name, $id, $npassword, $cpassword, $phone, $zone, $disablity, $file)
{
    if (empty($name) || empty($id) || empty($cpassword) || empty($npassword) || empty($phone) || empty($zone) || empty($disablity) || empty($file)) {
        return true;
    } else {
        return false;
    }
}
function checkpassword($p1, $p2)
{
    if ($p1 !== $p2) {
        return true;
    } else {
        return false;
    }
}
function uidexist($con, $id)
{
    $sql = "SELECT * FROM regtable WHERE userid = ?;";
    $stmt = mysqli_stmt_init($con);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location:../register.php?error=erroroccured");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (($row = mysqli_fetch_assoc($result)) > 0) {
        return $row;
    } else {
        return false;
    }
    mysqli_stmt_close($stmt);
}
function signup($con, $name, $id, $npassword, $phone, $zone, $disablity, $fileName, $regdate)
{
    $sql = "insert into regtable(name,userid,password,phone,zone,disablity,floc,regdate) values(?,?,?,?,?,?,?,?);";
    $stmt = mysqli_stmt_init($con);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location:../register.php?error=failed");
        exit();
    }
    include_once 'upload.php';
    $fileName = $target_file;
    mysqli_stmt_bind_param($stmt, "ssssssss", $name, $id, $npassword, $phone, $zone, $disablity, $fileName, $regdate);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    header("location:../login.php?registration_successful");
    exit();
}
//loginfunctions


function emptyInputLogin($id, $pword)

{
    if (empty($id) || empty($pword)) {
        return true;
    } else {
        return false;
    }
}
function loginUser($con, $userid, $password)
{
    $userExist = uidexist($con, $userid);
    if ($userExist === false) {
        header("location:../login.php?error=wronglogin");
        exit();
    }
    $pwdb = $userExist["password"];



    if ($pwdb !== $password) {
        header("location:../login.php?error=inccorectcredential");
        exit();
    } elseif ($pwdb === $password) {
        $_SESSION["userid"] = $userExist["userid"];
        $_SESSION["name"] = $userExist["name"];
        header("location:../UserDashboard/userdashboard.php");
        exit();
    }
}
function aidexist($con, $id)
{
    $sql = "SELECT * FROM admintable WHERE adminid = ?;";
    $stmt = mysqli_stmt_init($con);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location:../Admin/login.php?error=erroroccured");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (($row = mysqli_fetch_assoc($result)) > 0) {
        return $row;
    } else {
        return false;
    }
    mysqli_stmt_close($stmt);
}
function loginAdmin($con, $id, $password)
{
    $adminExist = aidexist($con, $id);
    if ($adminExist === false) {
        header("location:../Admin/login.php?error=wronglogin");
        exit();
    }
    $pwdb = $adminExist["password"];

    if ($pwdb !== $password) {
        header("location:../Admin/login.php?error=inccorectcredential");
        exit();
    } elseif ($pwdb === $password) {
        $_SESSION["adminid"] = $adminExist["adminid"];
        $_SESSION["name"] = $adminExist["name"];
        header("location:../Admin/admindashboard.php");
        exit();
    }
}
function midexist($con, $id)
{
    $sql = "SELECT * FROM mangtable WHERE 	mangid = ?;";
    $stmt = mysqli_stmt_init($con);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location:../Admin/manglogin.php?error=erroroccured");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (($row = mysqli_fetch_assoc($result)) > 0) {
        return $row;
    } else {
        return false;
    }
    mysqli_stmt_close($stmt);
}
$_SESSION["manid"];
function loginmang($con, $id, $password)
{
    $manExist = midexist($con, $id);
    if ($manExist === false) {
        header("location:../Admin/mangloign.php?error=wronglogin");
        exit();
    }
    $pwdb = $manExist["password"];

    if ($pwdb !== $password) {
        header("location:../Admin/manglogin.php?error=inccorectcredential");
        exit();
    } elseif ($pwdb === $password) {
        $_SESSION["manid"] = $manExist["mangid"];
        $_SESSION["name"] = $manExist["name"];
        header("location:../Admin/mangerdashboard.php");
        exit();
    }
}
<?php
session_start();
unset($_SESSION["manid"]);
header("location:../Admin/manglogin.php");
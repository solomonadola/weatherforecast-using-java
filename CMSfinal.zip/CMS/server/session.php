<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("location: ../Admin/login.php");
    exit();
}

<?php
session_start();

if (isset($_POST["submit"])) {
    $userid = $_POST["userid"];
    $pasword = $_POST["password"];
    require_once 'database.php';
    require_once 'functions.php';
    if (emptyInputLogin($userid, $pasword)) {
        header("location:../login.php?error=emptyinput");
        exit();
    }
    loginUser($con, $userid, $pasword);
} else {
    header("location:../login.php");
    exit();
}

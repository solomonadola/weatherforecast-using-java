<?php
session_start();

if (isset($_POST["submit"])) {
    $mes=$_POST['textarea'];
    require_once 'database.php';
    if (empty($mes)) {
        header("location:../Admin/mangerdashboard.php?error=emptymessage");
        exit();
    }
   $sql = "insert into message(messagebody)   values(?);";
    $stmt = mysqli_stmt_init($con);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location:../Admin/mangerdashboard.php?error=error");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "s",$mes);
    mysqli_stmt_execute($stmt);

    header("location:../Admin/mangerdashboard.php?messagesent");
    exit();
}
   
else {
    header("location:../Admin/manglogin.php");
    exit();
}

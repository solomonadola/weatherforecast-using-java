<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "condominium";
$con =new  mysqli($host, $username, $password, $dbname);
if (!$con) {
    die('connection failed');
}

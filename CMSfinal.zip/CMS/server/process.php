<?php
session_start();
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    include_once 'database.php';
    if ($con->query("delete from regtable where userid='$id'")) {
        $_SESSION['message'] = $id . " deleted successfully";
        $_SESSION['type'] = 'delete';

        header("location:../Admin/Admindashboard.php");
    } else {
        echo $con->error;
    }
}

if (isset($_GET['accept'])) {
    $id = $_GET['accept'];
    include_once 'database.php';

    if ($con->query("update regtable set status = 'accepted' where userid='$id'")) {
        $_SESSION['message'] = $id . " accepted ";
        $_SESSION['type'] = 'accepted';
        header("location:../Admin/Admindashboard.php");
    } else {
        echo $con->error;
    }
}
if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    include_once 'database.php';

    if ($con->query("update regtable set status = 'rejected' where userid='$id'")) {
        $_SESSION['message'] = $id . " reject ";
        $_SESSION['type'] = 'reject';
        header("location:../Admin/Admindashboard.php");
    } else {
        echo $con->error;
    }
}

<?php
session_start();
if (isset($_POST['submit'])) {
    $id = $_POST['manid'];
    $pwd = $_POST['password'];
    include_once '../server/functions.php';
    include_once 'database.php';
    
    if (emptyInputLogin($id, $pwd)) {
        header("location:../Admin/manglogin.php?error=emptyintput");
        exit();
    }
    else{
        loginmang($con,$id,$pwd);
    }
} else {
    header("location:../Admin/manglogin.php");
    exit();
}
